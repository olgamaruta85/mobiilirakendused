package com.example.opilane.zipcode;

public class Zipcode {
    private final String code;
    private final String city;
// ALT+Insert otkryvaet konstructor
    public Zipcode(String code, String city) {
        this.code = code;
        this.city = city;
    }

    public String getCode() {
        return code;
    }

    public String getCity() {
        return city;
    }

    public String toString(){
        return getCode() + " " + getCity();
    }
}
